package com.report.testcase;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import org.testng.AssertJUnit;
import org.testng.Reporter;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
@Listeners(com.report.listener.ListenerTest.class)
public class WebTest {
  private WebDriver driver;
  private String baseUrl;
  private StringBuffer verificationErrors = new StringBuffer();

  
 @BeforeClass
public void setUp() throws Exception {
	 System.setProperty("webdriver.chrome.driver", "C:\\Users\\309406\\Desktop\\Ebox\\Fitnesse CC\\chromedriver.exe");
    driver = new ChromeDriver();
    baseUrl = "http://apps.qa2qe.cognizant.e-box.co.in/AddressBook/";
    driver.manage().timeouts().implicitlyWait(500, TimeUnit.MILLISECONDS);
  }

  @Test (priority=1)	
  public void addAddressBook() throws Exception {
	driver.get(baseUrl + "/index.html");
    try {
    	driver.findElement(By.id("nickname")).clear();
        driver.findElement(By.id("nickname")).sendKeys("Poj");
        driver.findElement(By.id("contact")).clear();
        driver.findElement(By.id("contact")).sendKeys("Pooja");
        driver.findElement(By.id("company")).clear();
        driver.findElement(By.id("company")).sendKeys("Wipro");
        driver.findElement(By.id("city")).clear();
        driver.findElement(By.id("city")).sendKeys("Chennai");
        driver.findElement(By.id("country")).clear();
        driver.findElement(By.id("country")).sendKeys("India");
        driver.findElement(By.id("type")).clear();
        driver.findElement(By.id("type")).sendKeys("Sender");
        driver.findElement(By.id("add")).click();
     
    } catch (Error e) {
        verificationErrors.append("Cannot provide the input please stick to the UI constraints.\n");
    } catch(Exception e){
      	verificationErrors.append("Cannot provide the input please stick to the UI constraints.\n");
    }

    try {
      AssertJUnit.assertEquals("Nickname", driver.findElement(By.cssSelector("th")).getText());
      
    } catch (Error e) {
        verificationErrors.append("Element by id 'th' not found.\n");
      } catch (Exception e) {
      	verificationErrors.append("Element by id 'th' not found.\n");
      }
    
    try {
      AssertJUnit.assertEquals("City", driver.findElement(By.xpath("//div[@id='result']/table/tbody/tr/th[4]")).getText());
      
    } catch (Error e) {
        verificationErrors.append("Element by id 'th' not found.\n");
      } catch (Exception e) {
      	verificationErrors.append("Element by id 'th' not found.\n");
      }
    
    
    
    try {
      AssertJUnit.assertEquals("Pooja", driver.findElement(By.xpath("//div[@id='result']/table/tbody/tr[2]/td[2]")).getText());
      
    }catch (Error e) {
        verificationErrors.append("Element by id 'td' not found.\n");
      } catch (Exception e) {
      	verificationErrors.append("Element by id 'td' not found.\n");
      }
  Reporter.log("This test case will add the address book details"); 
  }
  
  @Test (priority=2)	
   public void updateAddressBook() throws Exception {
		  driver.findElement(By.id("radio0")).click();
		  
		  WebDriverWait wait = new WebDriverWait(driver, 120);
		  wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("edit")));
		  driver.findElement(By.id("edit")).click();
	
    driver.findElement(By.id("nickname")).clear();
    driver.findElement(By.id("nickname")).sendKeys("Pooja kumar");
    driver.findElement(By.id("contact")).clear();
    driver.findElement(By.id("contact")).sendKeys("Pooja");
    driver.findElement(By.id("company")).clear();
    driver.findElement(By.id("company")).sendKeys("Wipro");
    driver.findElement(By.id("city")).clear();
    driver.findElement(By.id("city")).sendKeys("Chennai");
    driver.findElement(By.id("country")).clear();
    driver.findElement(By.id("country")).sendKeys("India");
    driver.findElement(By.id("type")).clear();
    driver.findElement(By.id("type")).sendKeys("Sender");
    driver.findElement(By.id("add")).click();
    System.out.println(driver.findElement(By.xpath("//div[@id='result']/table/tbody/tr[2]/td[1]")));
    try {
        AssertJUnit.assertEquals("Pooja kumar", driver.findElement(By.xpath("//div[@id='result']/table/tbody/tr[2]/td[1]")).getText());
      
      }catch (Error e) {
          verificationErrors.append("Element by id 'td' not found.\n");
        } catch (Exception e) {
        	verificationErrors.append("Element by id 'td' not found.\n");
        }
    
    Reporter.log("This test case will add the address book details"); 
	  }
  
  
  
  @Test (priority=3)	
	  public void deleteAddressBook() throws Exception {
		  driver.findElement(By.id("radio0")).click();
		  WebDriverWait wait = new WebDriverWait(driver, 120);
		  wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("delete")));
		  driver.findElement(By.id("delete")).click();
		  try {
		        AssertJUnit.assertNotSame("Pooja kumar", driver.findElement(By.xpath("//div[@id='result']/table/tbody/tr[2]/td[1]")).getText());
		        
		      }catch (Error e) {
		          verificationErrors.append("Element by id 'td' not found.\n");
		        } catch (Exception e) {
		        	verificationErrors.append("Element by id 'td' not found.\n");
		        }
		  Reporter.log("This test case will delete the address book details from the array");     
  }
  
  @AfterClass
  public void driverClose() throws Exception {
		 driver.quit();
	  }
  
  
}


